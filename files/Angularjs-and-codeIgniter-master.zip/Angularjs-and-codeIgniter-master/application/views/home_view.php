<div ng-app>
	<b>jQuery ui directives( Please look at the file static/js/jQuery-ui-directive.js)</b><br>
	<input type="text" jq-date/>	<button jq-button>Home</button>
</div>

