Angularjs-and-codeIgniter
=========================

Fast web application development. There is an interactive code generator embedded with this application. Please read the user guide.
