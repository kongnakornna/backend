<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * Merge these values into your config.php file.
 */

$config['uri_protocol']	= "PATH_INFO";
$config['enable_hooks'] = TRUE;
$config['enable_query_strings'] = FALSE;
