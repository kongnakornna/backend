<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * Merge these values into your autoload.php file.
 */
 
$autoload['libraries'] = array('session');