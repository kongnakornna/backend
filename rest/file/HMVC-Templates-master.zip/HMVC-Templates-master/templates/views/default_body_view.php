<!-- Begin templates/views/default_body_view.php -->

</head>
<body>

<h1>Welcome to Modular Templating for HMVC Code Igniter!</h1>

 <!-- End templates/views/default_body_view.php -->
