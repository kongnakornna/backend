<!-- Begin templates/views/default_header_view.php -->

<!DOCTYPE html>

<html>
<head>
<title>Modular Templates for HMVC</title>

<!-- End templates/views/default_header_view.php -->
