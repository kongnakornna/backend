## 0.6 (2015-05-21)

Changes:

- var_dump function is used instead of print_r() to show configuration and session details.

## 0.5 (2015-05-17)

Bugfixes:

  - Support of HMVC, Overriding core/MY_Loader.php
  - Breaking view when adding config data which contains html tags

## 0.4 (2015-04-22)

Bugfixes:

- Add translation packages for some languages ( French, German, Russian, Italian, Spanish )
- Set the default translation to English if the translantion file does not exists.

